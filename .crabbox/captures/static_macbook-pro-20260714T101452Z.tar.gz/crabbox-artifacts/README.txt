Failure bundle files are local-only and not fully redacted. Review before sharing. Secret values are not intentionally written by Crabbox metadata.
